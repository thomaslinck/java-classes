package questao2;

public interface Colorido {
    public String getCor();
    public void setCor(String cor);
}
